// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Smykkeskrinstema",_layout_default:"Standardlayout",_layout_layout1:"Layout 1",emptyDocablePanelTip:"Klik p\u00e5 + knappen p\u00e5 Widget-fanen for at tilf\u00f8je en widget. ",_localized:{}}});