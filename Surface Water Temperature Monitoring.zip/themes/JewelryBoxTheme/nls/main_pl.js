// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Motyw Pude\u0142ko z bi\u017cuteri\u0105",_layout_default:"Uk\u0142ad domy\u015blny",_layout_layout1:"Uk\u0142ad 1",emptyDocablePanelTip:"Aby doda\u0107 wid\u017cet, kliknij na karcie Wid\u017cet przycisk \u201e+\u201d. ",_localized:{}}});