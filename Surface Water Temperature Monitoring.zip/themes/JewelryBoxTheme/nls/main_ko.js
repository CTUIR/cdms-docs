// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"\ubcf4\uc11d \uc0c1\uc790 \ud14c\ub9c8",_layout_default:"\uae30\ubcf8 \ub808\uc774\uc544\uc6c3",_layout_layout1:"\ub808\uc774\uc544\uc6c3 1",emptyDocablePanelTip:"\uc704\uc82f\uc744 \ucd94\uac00\ud558\ub824\uba74 \uc704\uc82f \ud0ed\uc5d0\uc11c + \ubc84\ud2bc\uc744 \ud074\ub9ad\ud569\ub2c8\ub2e4. ",_localized:{}}});