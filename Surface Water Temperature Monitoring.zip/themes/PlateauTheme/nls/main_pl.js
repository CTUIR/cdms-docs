// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/nls/strings":{_themeLabel:"Motyw P\u0142askowy\u017c",_layout_default:"Kompozycja domy\u015blna",_layout_layout1:"Kompozycja 1",_localized:{}}});