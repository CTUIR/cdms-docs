// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"\u05d1\u05e7\u05e8 \u05db\u05d5\u05ea\u05e8\u05ea",signin:"\u05d4\u05ea\u05d7\u05d1\u05e8",signout:"\u05d4\u05ea\u05e0\u05ea\u05e7",about:"\u05d0\u05d5\u05d3\u05d5\u05ea",signInTo:"\u05d4\u05ea\u05d7\u05d1\u05e8 \u05d0\u05dc",cantSignOutTip:"\u05e4\u05d5\u05e0\u05e7\u05e6\u05d9\u05d4 \u05d6\u05d5 \u05d0\u05d9\u05e0\u05d4 \u05d6\u05de\u05d9\u05e0\u05d4 \u05d1\u05de\u05e6\u05d1 \u05ea\u05e6\u05d5\u05d2\u05d4 \u05de\u05e7\u05d3\u05d9\u05de\u05d4.",
_localized:{}}});