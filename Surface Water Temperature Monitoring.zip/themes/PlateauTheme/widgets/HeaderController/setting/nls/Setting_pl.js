// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/setting/nls/strings":{group:"Nazwa",openAll:"Otw\u00f3rz wszystko w panelu",dropDown:"Poka\u017c w menu rozwijanym",noGroup:"Brak skonfigurowanej grupy wid\u017cet\u00f3w",groupSetLabel:"Skonfiguruj w\u0142a\u015bciwo\u015bci grupy wid\u017cet\u00f3w",_localized:{}}});