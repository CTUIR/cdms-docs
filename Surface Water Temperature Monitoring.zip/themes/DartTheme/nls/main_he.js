// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/nls/strings":{_themeLabel:"\u05e2\u05e8\u05db\u05ea \u05e0\u05d5\u05e9\u05d0 \u05e8\u05e6\u05d5\u05e2\u05d4 \u05ea\u05d7\u05ea\u05d5\u05e0\u05d4",_layout_default:"\u05e4\u05e8\u05d9\u05e1\u05ea \u05d1\u05e8\u05d9\u05e8\u05ea \u05de\u05d7\u05d3\u05dc",_localized:{}}});